/**
 * Created by Alexandru.Negura on 6/28/2017.
 */
angular.module('hrApp',[]);
